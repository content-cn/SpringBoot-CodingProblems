package com.codingninjas.jpaqueries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaqueriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
