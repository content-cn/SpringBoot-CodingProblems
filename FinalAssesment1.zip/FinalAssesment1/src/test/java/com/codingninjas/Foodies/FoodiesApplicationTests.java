package com.codingninjas.Foodies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
